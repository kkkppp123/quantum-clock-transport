def test_math_identity():
    assert (2 + 2) == 4
