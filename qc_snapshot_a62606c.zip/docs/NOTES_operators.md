@"
# NOTES_operators

- Siatka: v in [1e-2, 50], n ~ 50..200.
- Theta: dyskretny -d/dv( w d/dv ), w ~ v^{2/3}, Dirichlet na brzegach.
- U(T) = m^2 T^2 v^2 (diag).
- O(T) = Theta + U(T) — Hermitowskie, dodatnio półokreślone.
"@ | Set-Content -Encoding UTF8 docs\NOTES_operators.md
